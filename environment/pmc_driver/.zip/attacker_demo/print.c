#include "color.h"
#include "stdio.h"

int main(){
    printf(
        RED "LOVE" RST
        BLUE "LOVE" RST
        GREEN "LOVE" RST
        MAGE "LOVE" RST
        CYAN "LOVE" RST
    );
    return 0;
}