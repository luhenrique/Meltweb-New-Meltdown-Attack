#!/bin/bash
for j in {1,2,4,8,16,32,64};
do
    for  ((i=1; i<=20; i ++));
    do 
        echo -e "round $j $i";
        ./attack_demo $j
        sleep 1
    done
done
