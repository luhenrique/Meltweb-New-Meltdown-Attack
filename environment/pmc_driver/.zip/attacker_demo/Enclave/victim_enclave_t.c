#include "victim_enclave_t.h"

#include "sgx_trts.h" /* for sgx_ocalloc, sgx_is_outside_enclave */
#include "sgx_lfence.h" /* for sgx_lfence */

#include <errno.h>
#include <mbusafecrt.h> /* for memcpy_s etc */
#include <stdlib.h> /* for malloc/free etc */

#define CHECK_REF_POINTER(ptr, siz) do {	\
	if (!(ptr) || ! sgx_is_outside_enclave((ptr), (siz)))	\
		return SGX_ERROR_INVALID_PARAMETER;\
} while (0)

#define CHECK_UNIQUE_POINTER(ptr, siz) do {	\
	if ((ptr) && ! sgx_is_outside_enclave((ptr), (siz)))	\
		return SGX_ERROR_INVALID_PARAMETER;\
} while (0)

#define CHECK_ENCLAVE_POINTER(ptr, siz) do {	\
	if ((ptr) && ! sgx_is_within_enclave((ptr), (siz)))	\
		return SGX_ERROR_INVALID_PARAMETER;\
} while (0)

#define ADD_ASSIGN_OVERFLOW(a, b) (	\
	((a) += (b)) < (b)	\
)


typedef struct ms_storeSecret_t {
	sgx_sealed_data_t* ms_storage;
	uint32_t ms_sealed_secret_size;
} ms_storeSecret_t;

typedef struct ms_loadSecret_t {
	sgx_sealed_data_t* ms_storage;
} ms_loadSecret_t;

typedef struct ms_encrypt_all_t {
	unsigned char* ms_input;
	unsigned char* ms_output;
} ms_encrypt_all_t;

typedef struct ms_encrypt_loop_t {
	unsigned char* ms_input;
	unsigned char* ms_output;
	int* ms_flag;
	int* ms_flag_out;
} ms_encrypt_loop_t;

static sgx_status_t SGX_CDECL sgx_createSecret(void* pms)
{
	sgx_status_t status = SGX_SUCCESS;
	if (pms != NULL) return SGX_ERROR_INVALID_PARAMETER;
	createSecret();
	return status;
}

static sgx_status_t SGX_CDECL sgx_getSecretSize(void* pms)
{
	sgx_status_t status = SGX_SUCCESS;
	if (pms != NULL) return SGX_ERROR_INVALID_PARAMETER;
	getSecretSize();
	return status;
}

static sgx_status_t SGX_CDECL sgx_storeSecret(void* pms)
{
	CHECK_REF_POINTER(pms, sizeof(ms_storeSecret_t));
	//
	// fence after pointer checks
	//
	sgx_lfence();
	ms_storeSecret_t* ms = SGX_CAST(ms_storeSecret_t*, pms);
	sgx_status_t status = SGX_SUCCESS;
	sgx_sealed_data_t* _tmp_storage = ms->ms_storage;



	storeSecret(_tmp_storage, ms->ms_sealed_secret_size);


	return status;
}

static sgx_status_t SGX_CDECL sgx_loadSecret(void* pms)
{
	CHECK_REF_POINTER(pms, sizeof(ms_loadSecret_t));
	//
	// fence after pointer checks
	//
	sgx_lfence();
	ms_loadSecret_t* ms = SGX_CAST(ms_loadSecret_t*, pms);
	sgx_status_t status = SGX_SUCCESS;
	sgx_sealed_data_t* _tmp_storage = ms->ms_storage;



	loadSecret(_tmp_storage);


	return status;
}

static sgx_status_t SGX_CDECL sgx_encrypt_all(void* pms)
{
	CHECK_REF_POINTER(pms, sizeof(ms_encrypt_all_t));
	//
	// fence after pointer checks
	//
	sgx_lfence();
	ms_encrypt_all_t* ms = SGX_CAST(ms_encrypt_all_t*, pms);
	sgx_status_t status = SGX_SUCCESS;
	unsigned char* _tmp_input = ms->ms_input;
	unsigned char* _tmp_output = ms->ms_output;



	encrypt_all(_tmp_input, _tmp_output);


	return status;
}

static sgx_status_t SGX_CDECL sgx_encrypt_loop(void* pms)
{
	CHECK_REF_POINTER(pms, sizeof(ms_encrypt_loop_t));
	//
	// fence after pointer checks
	//
	sgx_lfence();
	ms_encrypt_loop_t* ms = SGX_CAST(ms_encrypt_loop_t*, pms);
	sgx_status_t status = SGX_SUCCESS;
	unsigned char* _tmp_input = ms->ms_input;
	unsigned char* _tmp_output = ms->ms_output;
	int* _tmp_flag = ms->ms_flag;
	int* _tmp_flag_out = ms->ms_flag_out;



	encrypt_loop(_tmp_input, _tmp_output, _tmp_flag, _tmp_flag_out);


	return status;
}

SGX_EXTERNC const struct {
	size_t nr_ecall;
	struct {void* ecall_addr; uint8_t is_priv; uint8_t is_switchless;} ecall_table[6];
} g_ecall_table = {
	6,
	{
		{(void*)(uintptr_t)sgx_createSecret, 0, 0},
		{(void*)(uintptr_t)sgx_getSecretSize, 0, 0},
		{(void*)(uintptr_t)sgx_storeSecret, 0, 0},
		{(void*)(uintptr_t)sgx_loadSecret, 0, 0},
		{(void*)(uintptr_t)sgx_encrypt_all, 0, 0},
		{(void*)(uintptr_t)sgx_encrypt_loop, 0, 0},
	}
};

SGX_EXTERNC const struct {
	size_t nr_ocall;
} g_dyn_entry_table = {
	0,
};


