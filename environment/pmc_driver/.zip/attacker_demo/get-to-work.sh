#!/bin/bash

for  ((i=1; i<=500; i ++));
do 
    echo -e "round $i";
    ./attack_demo 64 2>/dev/null;
    sleep 1
done
