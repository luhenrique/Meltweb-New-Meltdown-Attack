#!/bin/bash

printf "Stop Counters\n"
./pmctest stopcounters 1 9 100 311
