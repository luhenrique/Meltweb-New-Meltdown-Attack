#!/bin/bash
printf "Start Counters\n"
./pmctest startcounters 1 9 100 311
